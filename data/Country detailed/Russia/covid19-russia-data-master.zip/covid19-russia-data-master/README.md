# covid19 regional data for Russia

Parsed data with number of COVID-19 cases in russian regions

Main data source is [Оперативный штаб РФ по борьбе с коронавирусом](https://стопкоронавирус.рф/)

## Notes

Region name may vary, always use region id.

Region id = 99 means overall data.
