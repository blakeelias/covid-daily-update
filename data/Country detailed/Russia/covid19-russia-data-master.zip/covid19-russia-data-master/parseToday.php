<?php

require_once 'library.php';

ParseToday();