# covid-19-ukraine
This is COVID-19 data for Ukraine country (collected from [https://covid19.rnbo.gov.ua/](https://covid19.rnbo.gov.ua/))
